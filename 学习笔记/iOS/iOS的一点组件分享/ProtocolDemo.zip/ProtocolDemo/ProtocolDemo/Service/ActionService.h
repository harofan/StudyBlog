//
//  ActionService.h
//  ProtocolDemo
//
//  Created by Link on 2019/3/28.
//  Copyright © 2019 Link. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UCRuntimeKit/UCMediatorArgument.h>

NS_ASSUME_NONNULL_BEGIN

#define UCACTION_SERVICE_EXTERN_METHOD(className, methodName, argu) - (nullable id) ActionService_##className##_##methodName:(nullable UCMediatorArgument *)argu

@interface ActionService : NSObject
@end

NS_ASSUME_NONNULL_END

