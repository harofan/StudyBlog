//
//  UCRouter.h
//  ProtocolDemo
//
//  Created by Link on 2019/3/29.
//  Copyright © 2019 Link. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UCRuntimeKit/UCMediatorArgument.h>

NS_ASSUME_NONNULL_BEGIN

#define UCROUTER_OPEN_NATIVE(TARGET, ACTION, ARGU) \
[[UCRouter sharedInstance] openNativeTarget:TARGET action:ACTION argu:ARGU];

#define UC_TARGET_KEY(name) static NSString *const name = @#name;
#define UC_EVENT_KEY(name) static NSString *const name = @#name;

UC_TARGET_KEY(ModuleA)
UC_TARGET_KEY(ModuleB)

UC_EVENT_KEY(getVC)
UC_EVENT_KEY(log111)

@interface UCRouter : NSObject

+ (UCRouter *)sharedInstance;

- (nullable id)openUrl:(NSString *)url;
- (nullable id)openNativeUrl:(NSString *)url argu:(nullable UCMediatorArgument *)argu;
- (nullable id)openNativeTarget:(NSString *)targetName
                         action:(NSString *)action
                           argu:(nullable UCMediatorArgument *)argu;
@end

NS_ASSUME_NONNULL_END
