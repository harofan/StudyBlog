//
//  AppDelegateExchange.m
//  ProtocolDemo
//
//  Created by Link on 2019/3/29.
//  Copyright © 2019 Link. All rights reserved.
//

#import "AppDelegateExchange.h"
#import <UCAppDelegateReduce/UCAppDelegateReduce.h>

@implementation AppDelegateExchange

+ (void)load {
    UCAppDelegateMethodExchangeManager *manager = [UCAppDelegateMethodExchangeManager share];
    // sendMessageType 是位移枚举,可以选择自己想给子模块派发的方法
    UCAppDelegateConfigModel *model1 = [[UCAppDelegateConfigModel alloc] initWithModuleName:@"ModuleAAppDelegate" sendMessageType:didFinishLaunchingWithOptions];
    UCAppDelegateConfigModel *model2 = [[UCAppDelegateConfigModel alloc] initWithModuleName:@"ModuleBAppDelegate" sendMessageType:handleOpenURL | didFinishLaunchingWithOptions];

    [manager startExchangeMethodWithOriginalAppDelegateName:@"AppDelegate" newModuleAppDelegateConfigArray:@[model1, model2]];
}
@end
