//
//  AppDelegateExchange.h
//  ProtocolDemo
//
//  Created by Link on 2019/3/29.
//  Copyright © 2019 Link. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface AppDelegateExchange : NSObject

@end

NS_ASSUME_NONNULL_END
