//
//  UCRouter.m
//  ProtocolDemo
//
//  Created by Link on 2019/3/29.
//  Copyright © 2019 Link. All rights reserved.
//

#import "UCRouter.h"
#import <UCRuntimeKit/UCMediator.h>

@implementation UCRouter

+ (UCRouter *)sharedInstance
{
    static UCRouter * instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    return instance;
}

- (nullable id)openUrl:(NSString *)url {
    
    return nil;
}

- (nullable id)openNativeUrl:(NSString *)url argu:(nullable UCMediatorArgument *)argu {
    
    return nil;
}

- (nullable id)openNativeTarget:(NSString *)targetName
                         action:(NSString *)action
                           argu:(nullable UCMediatorArgument *)argu {
    
    NSString *selName = [NSString stringWithFormat:@"ActionService_%@_%@:", targetName, action];
    return [[UCMediator sharedInstance] nativePerformTarget:@"ActionService"
                                                     action:selName
                                                     params:argu.arguDict
                                                 completion:argu.completionCallBack
                                                    failure:argu.failureCallBack];
    
}
@end
