//
//  ActionService+ModuleA.m
//  ProtocolDemo
//
//  Created by Link on 2019/3/29.
//  Copyright © 2019 Link. All rights reserved.
//

#import "ActionService+ModuleA.h"
#import "ModuleAVC.h"

@implementation ActionService (ModuleA)

UCACTION_SERVICE_EXTERN_METHOD(ModuleA, getVC, argu) {
    return [ModuleAVC new];
}

@end
