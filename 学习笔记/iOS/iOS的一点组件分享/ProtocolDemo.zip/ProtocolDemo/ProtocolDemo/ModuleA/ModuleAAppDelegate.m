//
//  ModuleAAppDelegate.m
//  ProtocolDemo
//
//  Created by Link on 2019/3/29.
//  Copyright © 2019 Link. All rights reserved.
//

#import "ModuleAAppDelegate.h"

@implementation ModuleAAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    NSLog(@"🍎🍎🍎🍎🍎🍎🍎🍎🍎🍎🍎🍎模块A didFinishLaunchingWithOptions start!");
    return YES;
}

@end
