//
//  ModuleAVC.m
//  ProtocolDemo
//
//  Created by Link on 2019/3/28.
//  Copyright © 2019 Link. All rights reserved.
//

#import "ModuleAVC.h"
#import "UCRouter.h"

@interface ModuleAVC ()

@end

@implementation ModuleAVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.title = @"ModuleA";
}


@end
