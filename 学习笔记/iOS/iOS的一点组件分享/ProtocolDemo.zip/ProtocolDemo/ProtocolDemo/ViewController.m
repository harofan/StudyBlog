//
//  ViewController.m
//  ProtocolDemo
//
//  Created by Link on 2019/3/28.
//  Copyright © 2019 Link. All rights reserved.
//

#import "ViewController.h"
#import "UCRouter.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (IBAction)clickGoModuleABtn:(id)sender {

    UIViewController *vc = UCROUTER_OPEN_NATIVE(ModuleA, getVC, nil)
    [self.navigationController pushViewController:vc animated:YES];
}

- (IBAction)clickGoModuleBBtn:(id)sender {
    UCROUTER_OPEN_NATIVE(ModuleB, log111, nil)
}
@end
