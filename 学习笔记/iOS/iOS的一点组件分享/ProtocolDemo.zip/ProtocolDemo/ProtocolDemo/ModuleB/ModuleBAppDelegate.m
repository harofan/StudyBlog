//
//  ModuleBAppDelegate.m
//  ProtocolDemo
//
//  Created by Link on 2019/3/29.
//  Copyright © 2019 Link. All rights reserved.
//

#import "ModuleBAppDelegate.h"

@implementation ModuleBAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
     NSLog(@"🍎🍎🍎🍎🍎🍎🍎🍎🍎🍎🍎🍎模块B didFinishLaunchingWithOptions start!");
    return YES;
}
@end
