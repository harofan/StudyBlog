//
//  ActionService+ModuleB.m
//  ProtocolDemo
//
//  Created by Link on 2019/3/29.
//  Copyright © 2019 Link. All rights reserved.
//

#import "ActionService+ModuleB.h"

@implementation ActionService (ModuleB)

UCACTION_SERVICE_EXTERN_METHOD(ModuleB, log111, argu) {
    
    NSLog(@"🍎🍎🍎🍎🍎🍎🍎🍎🍎🍎🍎🍎🍎🍎🍎🍎🍎🍎🍎🍎🍎打印下");
    return nil;
}
@end
